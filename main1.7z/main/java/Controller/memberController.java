package Controller;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import Dao.member.memberDao;
import Dao.member.memberQuery;
import Model.member;

@Controller
@RequestMapping(value="/member")
public class memberController {
	
	//������n�J�s������	
	@RequestMapping("/login")
	public String login()
	{
		return "login";
	}
	//�n�� �P�_�b���P�K�X
	@RequestMapping("/checkUser")
	public String checkUser(HttpServletRequest request,HttpSession session) throws Exception
	{
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		member m=memberQuery.checkUser(username,password);
		if(m!=null)
		{
			session.setAttribute("M",m);
			return "loginSuccess";				
		}
		else
		{
			return "loginError";
		}
	}
	//���U�|��
	@RequestMapping("/addmember")
	public String addmember()
	{
		return "member/addMember";
	}
	//�s�W�|��(Person p)->p.getAge()
	@RequestMapping("/create")
	public String Create(member m) throws Exception
	{
		if(memberQuery.checkUser(m.getUsername())!=null)
		{
			return "redirect:../index.jsp";
		}
		else
		{
			new memberDao().add(m);	
		
			return "redirect:index";
		}
	}
	
	@RequestMapping("/create2")
	public String create2(member m) throws Exception
	{
		if(m.getUsername()!="")
		{
			return "addSuccess";
		}
		else
		{
			return "addError";
		}
		/*if(memberQuery.checkUser(m.getUsername())!=null) {
		
		return new ModelAndView("addError");
	  }
		else {
		           new memberDao().add(m);
		           return new ModelAndView("addSuccess");
		}*/
	}
}