package Dao.message;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Dao.implDao;
import Model.member;

public class messageDao implements implDao {

	public static void main(String[] args) {
		System.out.println(implDao.getDb());

	}

	@Override
	public void add(Object o) {
		Session se=implDao.getDb();
		Transaction tx=se.beginTransaction();
		se.save(o);
		tx.commit();
		se.close();
		
	}

	@Override
	public Object read(int id) {
		Session se=implDao.getDb();
		member m=se.get(member.class,id);
		return m;
	}

	@Override
	public void update(Object o) {
		Session se=implDao.getDb();
		Transaction tx=se.beginTransaction();
		se.save(o);
		tx.commit();
		se.close();
		
	}

	@Override
	public void delete(int id) {
		Session se=implDao.getDb();
		member m=se.get(member.class, id);
		Transaction tx=se.beginTransaction();
		
		se.delete(m);
		tx.commit();
		se.close();
		
	}

}
