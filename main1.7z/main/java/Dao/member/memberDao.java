package Dao.member;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import Dao.ModelDI;
import Dao.implDao;
import FACT.factModel;
import Model.member;

public class memberDao implements implDao {

	public static void main(String[] args) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("spModel.xml");
		ApplicationContext ac1=new AnnotationConfigApplicationContext(ModelDI.class);
		factModel fm=ac1.getBean(factModel.class,"factModel");
		//fm.getM().setName("teacher");
		System.out.println(fm.getM().getName());
       
	}

	@Override
	public void add(Object o) {
		Session se=implDao.getDb();
		Transaction tx=se.beginTransaction();
		se.save(o);
		tx.commit();
		se.close();
		
	}

	@Override
	public Object read(int id) {
		Session se=implDao.getDb();
		member m=se.get(member.class,id);
		return m;
	}

	@Override
	public void update(Object o) {
		Session se=implDao.getDb();
		Transaction tx=se.beginTransaction();
		se.save(o);
		tx.commit();
		se.close();
		
	}

	@Override
	public void delete(int id) {
		Session se=implDao.getDb();
		member m=se.get(member.class, id);
		Transaction tx=se.beginTransaction();
		
		se.delete(m);
		tx.commit();
		se.close();
		
	}

}
