package Dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import Model.member;

public class memberDao implements implDao {
    public static void main(String args[])
    {
   	 member m=new member();
   	 m.add("ig", "tes", "3333", "4444", "5555", false);
   	 new memberDao().add(m);
    }
	@Override
	public void add(Object o) {
		Session se=implDao.getDB();
		Transaction tx=se.beginTransaction();
		
		se.save(o);
		tx.commit();
		se.close();
		
		
	}

	@Override
	public Object read(int id) {
		Session se=implDao.getDB();
		member m=se.get(member.class,id);
		
		return m;
	}

	@Override
	public void update(Object o) {
		Session se=implDao.getDB();
		Transaction tx=se.beginTransaction();
		
		se.update(o);
		tx.commit();
		se.close();
		
	}

	@Override
	public void delete(int id) {
		Session se=implDao.getDB();
		member m=se.get(member.class, id);
		Transaction tx=se.beginTransaction();
		
		se.delete(m);
		tx.commit();
		se.close();
		
	}

}
