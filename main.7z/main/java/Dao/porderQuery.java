package Dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import Model.porder;

public class porderQuery {
public static void main(String args[])
{
	//System.out.println(porderQuery.quertSum(3000, 4000));
	System.out.println(porderQuery.queryAll());
}
public static List queryAll()
{
	Session se=implDao.getDB();
	String hql="from porder";
	Query q=se.createQuery(hql);

	List l=q.list();

	return l;
}
public static List querySum(int start,int end)
{
	Session se=implDao.getDB();
	String hql="from porder p where p.sum>=?1 and p.sum<=?2";
	Query q=se.createQuery(hql);
	
	q.setParameter(1, start);
	q.setParameter(2, end);
	List l=q.list();
	for(Object o:l)
	{
		System.out.println(o);
	}
	return l;
}
public static List queryName(String name)
{

	Session se=implDao.getDB();
	String hql="from porder as p where p.name=?1";
	Query q=se.createQuery(hql);
	q.setParameter(1, name);
	List l=q.list();
	for(Object o:l)
	{
		System.out.println(o);
	}
	return l;
}
}
