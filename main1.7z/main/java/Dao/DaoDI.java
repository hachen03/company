package Dao;

public class DaoDI {

}
